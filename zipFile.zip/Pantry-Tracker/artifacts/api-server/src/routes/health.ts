import { Router, type IRouter } from "express";
import { GetHealthResponse, HealthCheckResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/health", (_req, res) => {
  res.json(GetHealthResponse.parse({ ok: true }));
});

router.get("/healthz", (_req, res) => {
  const data = HealthCheckResponse.parse({ status: "ok" });
  res.json(data);
});

export default router;
